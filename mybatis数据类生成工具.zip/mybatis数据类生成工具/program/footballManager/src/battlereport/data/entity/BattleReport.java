package battlereport.data.entity;

public class BattleReport {
    private Long iid;

    private byte[] replay;

    public Long getIid() {
        return iid;
    }

    public void setIid(Long iid) {
        this.iid = iid;
    }

    public byte[] getReplay() {
        return replay;
    }

    public void setReplay(byte[] replay) {
        this.replay = replay;
    }
}