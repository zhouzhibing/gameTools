package battlereport.data.mapper;

import battlereport.data.entity.BattleReport;

public interface BattleReportMapper {
    int deleteByPrimaryKey(Long iid);

    int insert(BattleReport record);

    int insertSelective(BattleReport record);

    BattleReport selectByPrimaryKey(Long iid);

    int updateByPrimaryKeySelective(BattleReport record);

    int updateByPrimaryKeyWithBLOBs(BattleReport record);
}