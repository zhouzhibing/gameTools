package db.mapper;

import db.entity.BattleReport;

public interface BattleReportMapper {
    int deleteByPrimaryKey(Long id);

    int insert(BattleReport record);

    int insertSelective(BattleReport record);

    BattleReport selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(BattleReport record);

    int updateByPrimaryKeyWithBLOBs(BattleReport record);

    int updateByPrimaryKey(BattleReport record);
}