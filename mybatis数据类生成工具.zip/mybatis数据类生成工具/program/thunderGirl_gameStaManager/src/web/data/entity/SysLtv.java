package web.data.entity;

public class SysLtv {
    private Long id;

    private String date;

    private String channel;

    private Integer newPlayCount;

    private String ltvJsonString;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date == null ? null : date.trim();
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel == null ? null : channel.trim();
    }

    public Integer getNewPlayCount() {
        return newPlayCount;
    }

    public void setNewPlayCount(Integer newPlayCount) {
        this.newPlayCount = newPlayCount;
    }

    public String getLtvJsonString() {
        return ltvJsonString;
    }

    public void setLtvJsonString(String ltvJsonString) {
        this.ltvJsonString = ltvJsonString == null ? null : ltvJsonString.trim();
    }
}