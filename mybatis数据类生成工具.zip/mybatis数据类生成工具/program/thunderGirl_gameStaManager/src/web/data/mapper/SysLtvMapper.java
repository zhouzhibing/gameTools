package web.data.mapper;

import web.data.entity.SysLtv;

public interface SysLtvMapper {
    int deleteByPrimaryKey(Long id);

    int insert(SysLtv record);

    int insertSelective(SysLtv record);

    SysLtv selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysLtv record);

    int updateByPrimaryKey(SysLtv record);
}