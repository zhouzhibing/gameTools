package game.data.sys.mapper;

import game.data.sys.entity.SysRoleMail;

public interface SysRoleMailMapper {
    int deleteByPrimaryKey(Long id);

    int insert(SysRoleMail record);

    int insertSelective(SysRoleMail record);

    SysRoleMail selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysRoleMail record);

    int updateByPrimaryKey(SysRoleMail record);
}