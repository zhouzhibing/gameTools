package game.data.sys.mapper;

import game.data.sys.entity.SysGuild;

public interface SysGuildMapper {
    int deleteByPrimaryKey(Long id);

    int insert(SysGuild record);

    int insertSelective(SysGuild record);

    SysGuild selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysGuild record);

    int updateByPrimaryKey(SysGuild record);
}